import argparse
import sys
import ssl
import time
import os
import paramiko
from tcms_api import TCMS

# 忽略自簽憑證警告
ssl._create_default_https_context = ssl._create_unverified_context

def log(msg):
    print(f"[BSP-MGR] {msg}", flush=True)

class RemoteTester:
    def __init__(self):
        self.ip = os.getenv('DUT_IP', '127.0.0.1')
        self.user = os.getenv('DUT_USER', 'root')
        self.password = os.getenv('DUT_PASSWORD')
        self.port = int(os.getenv('DUT_PORT', 22))
        
        log(f"Connecting to Device Under Test: {self.ip} ({self.user})...")
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        try:
            self.client.connect(
                self.ip, 
                port=self.port, 
                username=self.user, 
                password=self.password, 
                timeout=10,
                banner_timeout=10
            )
            log("SSH Connection Established!")
        except Exception as e:
            log(f"SSH Connection Failed: {e}")
            sys.exit(1)

    def run_command(self, command):
        stdin, stdout, stderr = self.client.exec_command(command)
        exit_status = stdout.channel.recv_exit_status()
        output = stdout.read().decode().strip()
        if exit_status != 0:
            error = stderr.read().decode().strip()
            log(f"Command '{command}' failed: {error}")
            return None
        return output

    def close(self):
        self.client.close()

class KiwiReporter:
    def __init__(self):
        log("Initializing Kiwi TCMS connection...")
        self.rpc = TCMS()
        
        self.product_name = os.getenv('KIWI_PRODUCT_NAME', 'Unknown-Device')
        self.product_id = self._get_or_create_product(self.product_name)

        self.version_value = "1.0"
        self.version_id = self._get_or_create_version(self.version_value)

        self.plan_name = f"{self.product_name}_BSP_Auto_v{self.version_value}"
        self.plan = self._get_or_create_plan()
        self.plan_id = self.plan['id']

        self.build = self._get_or_create_build()
        self.run = self._create_test_run()
        log(f"Kiwi Setup Ready! Plan: {self.plan_name} (ID: {self.plan_id})")

    def _get_or_create_product(self, name):
        products = self.rpc.exec.Product.filter({'name': name})
        if products: return products[0]['id']
        return self.rpc.exec.Product.create({'name': name, 'description': 'Auto-created'})['id']

    def _get_or_create_version(self, version_value):
        versions = self.rpc.exec.Version.filter({'product': self.product_id, 'value': version_value})
        if versions: return versions[0]['id']
        return self.rpc.exec.Version.create({'product': self.product_id, 'value': version_value})['id']

    def _get_or_create_plan(self):
        plans = self.rpc.exec.TestPlan.filter({
            'name': self.plan_name, 
            'product': self.product_id,
            'product_version': self.version_id
        })
        if plans: return plans[0]
        return self.rpc.exec.TestPlan.create({
            'name': self.plan_name, 
            'product': self.product_id, 
            'product_version': self.version_id, 
            'type': 1, 
            'text': f'BSP Auto Plan for {self.product_name} v{self.version_value}'
        })

    def _get_or_create_build(self):
        build_name = "CI-Automated-Build"
        builds = self.rpc.exec.Build.filter({'name': build_name, 'version': self.version_id})
        if builds: return builds[0]
        return self.rpc.exec.Build.create({'name': build_name, 'version': self.version_id, 'is_active': True})

    def _create_test_run(self):
        return self.rpc.exec.TestRun.create({
            'plan': self.plan_id, 
            'build': self.build['id'], 
            'summary': f"Remote Check {time.strftime('%Y-%m-%d %H:%M')}", 
            'manager': 1
        })

    def report(self, case_summary, status, info_text=""):
        # 1. 找或建立 Case
        cases = self.rpc.exec.TestCase.filter({'summary': case_summary})
        if cases:
            case_id = cases[0]['id']
        else:
            case_id = self.rpc.exec.TestCase.create({
                'summary': case_summary, 
                'category': 1, 
                'priority': 1, 
                'case_status': 2, 
                'text': 'System Resource Check'
            })['id']

        # 2. 加入 Run
        executions = self.rpc.exec.TestRun.add_case(self.run['id'], case_id)
        if not executions: return
        execution_id = executions[0]['id']

        # 3. 更新結果 - 策略 A: 嘗試寫入多個文字欄位 (Execution Level)
        # 這樣點進 TE-xx 裡面的 Notes 也有機會看到
        status_id = 4 if status == 'PASS' else 5
        log(f"Updating Execution ID {execution_id}...")
        
        try:
            self.rpc.exec.TestExecution.update(execution_id, {
                'status': status_id,
                'comment': info_text,       
                'notes': info_text,         
                'text': info_text,          
                'actual_result': info_text  
            })
        except Exception as e:
            log(f"Warning: Standard update failed partially: {e}")

        # 4. 更新結果 - 策略 B: 寫入 Test Run 的備註 (Run Level)
        # 這是您剛剛確認成功看到 "--- Automated Test Results ---" 的地方
        try:
            log("Updating Test Run Notes...")
            self.rpc.exec.TestRun.update(self.run['id'], {
                'notes': f"--- Automated Test Results ---\n{info_text}"
            })
        except Exception as e:
            log(f"Warning: Failed to update Test Run notes: {e}")

        # (已移除) 策略 C: 修改標題

        log(f"Reported: {case_summary} -> {status}")

def get_system_info(remote):
    log("Reading Remote System Information...")
    try:
        cpu_info = remote.run_command("grep 'model name' /proc/cpuinfo | head -n 1 | cut -d: -f2")
        mem_info = remote.run_command("free -h | grep Mem | awk '{print $2}'")
        kernel_info = remote.run_command("uname -r")

        if not cpu_info: 
            return False, "Failed to retrieve info via SSH"

        info_str = f"CPU: {cpu_info.strip()}\nRAM: {mem_info.strip()}\nKernel: {kernel_info.strip()}"
        log(f"Remote Result: {info_str}")
        return True, info_str
    except Exception as e:
        return False, str(e)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest='command', required=True)
    p_check = subparsers.add_parser('system_check')
    args = parser.parse_args()
    
    tester = RemoteTester()
    reporter = KiwiReporter()

    if args.command == 'system_check':
        success, info = get_system_info(tester)
        reporter.report("OS Resource Check", "PASS" if success else "FAIL", info_text=info)
        tester.close()
        if not success: sys.exit(1)