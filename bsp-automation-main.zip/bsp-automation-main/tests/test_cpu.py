import pytest

class TestCPU:
    """Test Plan: 1_02_01_CPU_Function_Test"""

    def test_cpu_model_check(self, dut_ssh):
        """1.02.01 - Check CPU Model Name"""
        # 呼叫我們改寫過的 exec_command
        stdin, stdout, stderr = dut_ssh.exec_command("grep 'model name' /proc/cpuinfo | head -n 1")
        
        output = stdout.read().decode().strip()
        print(f"\n[Check] CPU Info Raw: {output}")

        expected_keywords = ["ARMv8", "Tegra", "Intel", "AMD"]
        
        # Serial 有時候會多出一些空行，用 in 來判斷最安全
        assert any(x in output for x in expected_keywords), \
            f"CPU Model check failed! Got: {output}"

    def test_cpu_core_count(self, dut_ssh):
        """1.02.01 - Check CPU Core Count"""
        stdin, stdout, stderr = dut_ssh.exec_command("nproc")
        
        raw_out = stdout.read().decode().strip()
        # 有時候會有雜訊，嘗試轉型，失敗就 Fail
        try:
            count = int(raw_out)
            print(f"\n[Check] Core Count: {count}")
            assert count >= 4, f"Core count too low! Got {count}"
        except ValueError:
             pytest.fail(f"Could not parse core count from serial output: '{raw_out}'")

    def test_cpu_architecture(self, dut_ssh):
        """1.02.01 - Check Architecture"""
        stdin, stdout, stderr = dut_ssh.exec_command("uname -m")
        arch = stdout.read().decode().strip()
        print(f"\n[Check] Architecture: {arch}")
        
        assert arch in ["aarch64", "x86_64"], f"Unknown Architecture: {arch}"