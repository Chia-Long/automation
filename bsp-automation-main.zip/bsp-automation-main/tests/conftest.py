import pytest
import os
import time
import sys
import serial
import re
import ssl
import base64
from tcms_api import TCMS

# ============================================================================
# 0. 全域設定
# ============================================================================
if hasattr(ssl, '_create_unverified_context'):
    ssl._create_default_https_context = ssl._create_unverified_context

def log(msg):
    print(f"[BSP-AUTO] {msg}")

# ============================================================================
# 1. Serial Driver (保持不變)
# ============================================================================
class SerialDriver:
    def __init__(self, port, baudrate=115200, user="root", password=""):
        self.port = port
        self.baudrate = baudrate
        self.user = user
        self.password = password
        self.prompts = ["#", "$", "mic-711@ubuntu", "~#", "~$"] 
        
        log(f"Serial opening {port} at {baudrate}...")
        try:
            self.ser = serial.Serial(port, baudrate, timeout=1)
        except Exception as e:
            pytest.fail(f"Could not open serial port: {e}")

    def clean_ansi(self, text):
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    def login(self):
        log("Serial attempting to login...")
        self.ser.write(b"\n\n")
        time.sleep(1)
        output = self.read_buffer()

        if any(p in output for p in self.prompts):
            log("Serial already logged in.")
            return

        if "login:" in output or "Login:" in output:
            self.ser.write(self.user.encode() + b"\n")
            time.sleep(1)
            output = self.read_buffer()
        if "Password:" in output or "password:" in output:
            self.ser.write(self.password.encode() + b"\n")
            time.sleep(1)
            output = self.read_buffer()

        output = self.read_buffer()
        if not any(p in output for p in self.prompts):
            log(f"Login warning: {output[:30]}...")
        else:
            log("Serial login successful.")

    def read_buffer(self):
        time.sleep(0.5)
        if self.ser.in_waiting > 0:
            try:
                return self.ser.read(self.ser.in_waiting).decode('utf-8', errors='ignore')
            except:
                return ""
        return ""

    def read_until_prompt(self, timeout=10):
        buffer = ""
        start_time = time.time()
        while (time.time() - start_time) < timeout:
            chunk = self.read_buffer()
            if chunk:
                buffer += chunk
                if any(p in buffer.strip().split('\n')[-1] for p in self.prompts):
                    break
            time.sleep(0.1)
        return buffer

    def exec_command(self, command):
        log(f"Command sending: {command}")
        self.ser.reset_input_buffer()
        self.ser.write(command.encode() + b"\n")
        full_output = self.read_until_prompt(timeout=30)
        
        clean_text = self.clean_ansi(full_output)
        lines = clean_text.splitlines()
        content_lines = [l.strip() for l in lines if l.strip() and command not in l]
        content_lines = [l for l in content_lines if not (any(p in l for p in self.prompts) and len(l) < 30)]
        final_output = "\n".join(content_lines).strip()
        
        class MockStdout:
            def __init__(self, content): self.content = content
            def read(self): return self.content.encode()
            
        return (None, MockStdout(final_output), None)

    def close(self):
        self.ser.close()

# ============================================================================
# 2. Kiwi Reporter (修正上傳邏輯)
# ============================================================================
class KiwiReporter:
    def __init__(self):
        if not os.getenv('KIWI_PRODUCT_NAME'): return
        self.rpc = TCMS()
        self.product_name = os.getenv('KIWI_PRODUCT_NAME', 'Unknown')
        self.product_id = self._get_or_create_product(self.product_name)
        self.version_id = self._get_or_create_version("1.0")
        self.plan_id = self._get_or_create_plan()['id']
        self.build_id = self._get_or_create_build()['id']
        self.run_id = self._create_test_run()['id']

    def _get_or_create_product(self, name):
        p = self.rpc.exec.Product.filter({'name': name})
        return p[0]['id'] if p else self.rpc.exec.Product.create({'name': name})['id']

    def _get_or_create_version(self, val):
        v = self.rpc.exec.Version.filter({'product': self.product_id, 'value': val})
        return v[0]['id'] if v else self.rpc.exec.Version.create({'product': self.product_id, 'value': val})['id']

    def _get_or_create_plan(self):
        name = f"{self.product_name}_BSP_Auto_v1.0"
        p = self.rpc.exec.TestPlan.filter({'name': name, 'product': self.product_id})
        return p[0] if p else self.rpc.exec.TestPlan.create({'name': name, 'product': self.product_id, 'product_version': self.version_id, 'type': 1})

    def _get_or_create_build(self):
        name = "CI-Automated-Build"
        b = self.rpc.exec.Build.filter({'name': name, 'version': self.version_id})
        return b[0] if b else self.rpc.exec.Build.create({'name': name, 'version': self.version_id, 'is_active': True})

    def _create_test_run(self):
        return self.rpc.exec.TestRun.create({'plan': self.plan_id, 'build': self.build_id, 'summary': f"Pytest Run {time.strftime('%Y-%m-%d %H:%M')}", 'manager': 1})

    def report(self, case_summary, status, log_text=""):
        cases = self.rpc.exec.TestCase.filter({'summary': case_summary})
        case_id = cases[0]['id'] if cases else self.rpc.exec.TestCase.create({'summary': case_summary, 'category': 1, 'priority': 1, 'case_status': 2, 'text': 'Auto-generated'})['id']

        executions = self.rpc.exec.TestRun.add_case(self.run_id, case_id)
        if not executions: return
        execution_id = executions[0]['id']
        status_id = 4 if status == 'PASS' else 5

        # 1. 更新狀態
        self.rpc.exec.TestExecution.update(execution_id, {'status': status_id})

        # 2. 上傳附件 (自動降級機制)
        if log_text:
            try:
                b64_content = base64.b64encode(log_text.encode('utf-8')).decode('utf-8')
                # 檔名加上 Execution ID 以避免重複覆蓋
                filename = f"run_{execution_id}.log"
                
                sys.stderr.write(f"[DEBUG] Uploading attachment for TE-{execution_id}...\n")
                
                try:
                    # 優先嘗試：上傳到 Test Execution (新版 Kiwi)
                    self.rpc.exec.TestExecution.add_attachment(execution_id, filename, b64_content)
                    sys.stderr.write("[DEBUG] Success: Uploaded to TestExecution.\n")
                except Exception as e:
                    # 如果方法不存在，則降級
                    if "Method not found" in str(e):
                        sys.stderr.write(f"[DEBUG] Fallback: Uploading to TestCase-{case_id} (Server is old version)...\n")
                        # 降級嘗試：上傳到 Test Case (舊版 Kiwi 通用)
                        # 注意：這裡第一個參數變成 case_id
                        self.rpc.exec.TestCase.add_attachment(case_id, filename, b64_content)
                        sys.stderr.write("[DEBUG] Success: Uploaded to TestCase.\n")
                    else:
                        raise e # 如果是其他錯誤，則拋出
                
            except Exception as e:
                sys.stderr.write(f"[ERROR] Attachment upload failed: {e}\n")

# ============================================================================
# 3. Pytest Hooks
# ============================================================================
_global_reporter = None

@pytest.fixture(scope="session")
def dut_ssh():
    port = os.getenv('DUT_PORT', '/dev/ttyUSB0')
    baud = int(os.getenv('DUT_BAUD', 115200))
    user = os.getenv('DUT_USER', 'root')
    password = os.getenv('DUT_PASSWORD', 'root')
    client = SerialDriver(port, baud, user, password)
    client.login()
    yield client
    client.close()

@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()

    if rep.when == "call" and os.getenv('KIWI_PRODUCT_NAME'):
        case_summary = item.name 
        status = 'PASS' if rep.passed else 'FAIL'
        
        captured_log = rep.capstdout 
        final_note = f"{captured_log}" if captured_log else f"(No Log Captured)"
        if rep.failed: final_note += f"\n\nERROR:\n{rep.longreprtext}"

        try:
            _quick_report_to_kiwi(case_summary, status, final_note)
        except Exception as e:
            sys.stderr.write(f"[ERROR] Hook failed: {e}\n")

def _quick_report_to_kiwi(summary, status, comment):
    global _global_reporter
    if _global_reporter is None:
        try:
            _global_reporter = KiwiReporter()
        except: return
    _global_reporter.report(summary, status, comment)